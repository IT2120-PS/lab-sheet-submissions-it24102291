setwd("./IT24102291")

# 1. Import the dataset (’Exercise.txt’) into R and store it in a data frame called ”branch data”.
branch_data <- read.table('Exercise.txt', header = TRUE, sep=",")
str(branch_data)

3. Obtain boxplot for sales and interpret the shape of the sales distribution.
boxplot(
  branch_data$Sales_X1,
  main="Box plot for Sales",
  outline = TRUE,
  outpch = 8,
  horizontal = TRUE
)

# 4. Calculate the five number summary and IQR for advertising variable.
summary(branch_data$Advertising_X2)

# 5. Write an R function to find the outliers in a numeric vector and check for outliers in years variables.
get.outliers <- function(dataset){
  q1 <- quantile(dataset, 0.25)
  q3 <- quantile(dataset, 0.75)
  iqr <- IQR(dataset)
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- dataset[dataset < lower_bound | dataset > upper_bound]
  return(outliers)
}

outliers_years <- get.outliers(branch_data$Years_X3)
print(outliers_years)
# 