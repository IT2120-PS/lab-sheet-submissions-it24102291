setwd("C:/Users/it24102291/Downloads/IT24102291")

# 1. Import the dataset (’Exercise – Lab 05.txt’) into R and store it in a data frame called ”Delivery Times”.
Delivery_Times <- read.table('Exercise - Lab 05.txt', header=TRUE, sep=",")
names(Delivery_Times) <- c('Minutes')

# 2. Draw a histogram for deliver times using nine class intervals where the lower limit is 20 and upper limit is 70. Use right open intervals.
histrogm <- hist(
  Delivery_Times$Minutes, 
  main = "Histogram for Deliver Times", 
  xlab = "Delivery Duration (minutes)",
  breaks = seq(20, 70, length = 10),
  right = FALSE
)
lines(histrogm$mids, histrogm$counts)

# 4. Draw a cumulative frequency polygon (ogive) for the data in a separate plot.
cum.freq <- c(0, cumsum(histrogm$counts))
plot(histrogm$breaks, cum.freq, type = "l",
     main = "Cumulative Frequency Polygon for Deliver Time",
     xlab = "Deliver Times (min)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))